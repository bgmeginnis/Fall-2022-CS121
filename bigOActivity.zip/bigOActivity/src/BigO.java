public class BigO {
    public void printOnce(int n) {
        for (int i = 0 ; i < 100; i++)
        {
            System.out.println("Rick + Morty");
        }
    }
    public void printNTimes(int n) {
        for (int i = 0 ; i < n; i++)
        {
            System.out.println("Rick + Morty");
        }
    }
    public void printNSquaredTimes(int n) {
        for (int i = 0 ; i < n ; i++)
        {
            for (int j = 0; j < n ; j++) {
                System.out.println("Rick + Morty");
            }
        }
    }
}
