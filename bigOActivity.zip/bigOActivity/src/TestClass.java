import java.lang.reflect.Array;
import java.lang.Integer;


public class TestClass {
    public static void main(String[] args) {
        BigO testBigO = new BigO();
        testBigO.printOnce(5);
        testBigO.printNTimes(5);
        testBigO.printNSquaredTimes(5);
        //System.out.println("value:",testBigO.printOnce(5));
       // Integer = testBigO.printOnce(4);
        //Integer newPrintNTimes = testBigO.printNTimes(4);
        //Integer newPrintNSquaredTimes = testBigO.printNSquaredTimes(4);
    }
}
